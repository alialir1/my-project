# atlantic_api

A Dart client that walks back from `https://atlantic.bz/title/movie/{id}` to **every
playback server** the site uses, gives you the **direct stream URL** for each quality,
and computes a **file size** for each of them.

Pure Dart, no browser, no headless Chrome, no keys. Works on movies and TV episodes.

```bash
dart pub get
dart run bin/atlantic.dart resolve https://atlantic.bz/title/movie/1368337
```

```
The Odyssey (2026)
------------------------------------------------------------------------------
Bolo         1080p      5.48 GB    sampled
   https://api.embedbandit.com/api/stream/ck4GAS919u5_DvqUv4vxLQ/video/1080p/index.m3u8
   subs: English (SDH), English
Bolo         720p       2.21 GB    sampled
   https://api.embedbandit.com/api/stream/ck4GAS919u5_DvqUv4vxLQ/video/720p/index.m3u8
Dizipal      1080p      2.66 GB    sampled
   https://route.transcode.cfd/m3u8-proxy.m3u8?data=...
Vixsrc       720p       1.26 GB    sampled
   https://route.transcode.cfd/m3u8-proxy.m3u8?data=...
Prism        English 1080p  2.20 GB  estimated
   https://stream.hls.lol/mbox/mpd?q=...
Athena       1080p      503 KB     exact
   https://totallyacdn.cc/aws/hls/261019/video_1080p.m3u8?sign=...
...
14 links · 583 subtitles · 4834 ms
```

---

## How the site actually works

`atlantic.bz` is a Vite/React SPA. The title page ships an empty `<div id="root">`;
everything is fetched by the bundle. The interesting part is the player: it does **not**
proxy video through its own origin. It calls a set of independent "resolver" hosts, each
of which returns a ready-to-play HLS/DASH URL, and the `<video>` element then talks
straight to the CDN.

The hosts, and what each one wants:

| Provider   | Endpoint                                                              | Shape |
|------------|-----------------------------------------------------------------------|-------|
| **Athena** | `cdn.hls.lol/content/movie/{tmdb}` · `cdn.hls.lol/content/tv/{tmdb}/{s}/{e}` | `{found, title, url, type}` — also the cheapest way to learn the title |
| **Vidbox** | `stream.hls.lol/vidbox?tmdbId=&type=[&season=&episode=]`              | `{sources:{Name:{label,server,type,url,expiresAt}}}` |
| **Play4U** | `stream.hls.lol/play4u?…`                                             | `{languages[],qualities[],url}` — embed page |
| **Prism**  | `stream.hls.lol/mbox?…`                                               | `{tracks[{quality,lang,mode,url}], subtitles[]}` — DASH, one track per dub |
| **Bandit** | `pal.hls.lol/bandit/streams?type=&tmdb=&season=&episode=`              | `{servers:[{name,cached,streams[{quality,url,subtitles}]}]}` |
| **VixSrc** | `it.hls.lol/resolve?tmdbId=&type=`                                    | `{sources:{…}}` |
| **Dizipal**| `pal.hls.lol/resolve?tmdbId=&type=&title=&year=`                      | `{sources:{…}, subtitles[]}` — **needs a title** |
| **Shegu**  | `shegu.hls.lol/resolve/{type}/{id}[/{s}/{e}]`                         | often `{found:false}` |
| **FSOnline**| `pal.hls.lol/fs/embed?title=&type=&year=`                            | `{page, embeds[{name,url}]}` — embed pages |
| **Dash**   | `dash.hls.lol/resolve?type=&tmdbId=&title=&year=`                     | flaky upstream |
| *subtitles*| `natsuki.hls.lol/subs?tmdbId=` · `sub.vdrk.site/v1/{type}/{id}`        | 500+ community subs |

Two details that matter in practice:

* Every provider wants `Referer: https://atlantic.bz/` and `Origin: https://atlantic.bz`.
  Without them the CDN answers `403 forbidden`.
* `Dizipal` and `Dash` refuse to answer without a `title`, so the client runs a **second
  wave** after the first wave (Athena) reports the canonical title. You only ever pass a
  TMDB id.
* Provider links are short-lived. The `transcode.cfd` proxies embed a signed payload in
  the query string and start returning `forbidden` a few minutes after issue, which is
  why size probing happens immediately after resolution.

### Where the file sizes come from

No provider publishes a size. But every CDN does expose one of two things:

* `Content-Length` on the segment (plain HEAD), or
* `Content-Range: bytes 0-0/1169936` on a **one-byte ranged GET** — Cloudflare strips
  `Content-Length` from HEAD but happily tells you the total this way.

So the probe fetches the media playlist, and for each segment reads the real byte count
and sums it. Three modes:

| `--size`    | What it does | Requests |
|-------------|--------------|----------|
| `none`      | skip | 0 |
| `estimated` | duration × declared `AVERAGE-BANDWIDTH`/`BANDWIDTH` ÷ 8 | 0 extra |
| `sampled`   | measures N evenly-spread segments, extrapolates over the segment count (default, 10) | N per variant |
| `exact`     | measures **every** segment; falls back to `sampled` above 400 segments | all |

Master playlists are expanded into one entry per quality by default (`--no-expand` keeps
them whole). If the playlist is byte-range based (`#EXT-X-BYTERANGE`), the sizes are read
straight out of the manifest with zero extra requests.

Every size carries a `mode` (`exact` / `sampled` / `estimated` / `unavailable`) plus a
`note`, so you always know how much to trust a number.

---

## Usage

### CLI

```bash
dart run bin/atlantic.dart resolve <target> [options]
```

Targets accepted:

```
https://atlantic.bz/title/movie/1368337
https://atlantic.bz/watch/1399/1/1
movie:1368337
1399:1:1          # shorthand for tv, s1e1
1368337           # movie by default
```

Options:

```
-s, --size <mode>      none | estimated | sampled | exact   (default: sampled)
-p, --provider <name>  only query one provider (repeatable)
    --no-expand        keep HLS master playlists as a single entry
    --max-variants <n>  probe at most n variants per master (0 = all)
-c, --concurrency <n>  parallel requests               (default: 8)
    --sample <n>       segments measured per variant   (default: 10)
    --title <text>     override the resolved title
    --year <n>         override the resolved year
-j, --json [file]      write JSON ('-' = stdout)
-t, --table            tab-separated rows
-q, --quiet            no human output
```

Exit codes: `0` ok · `1` no servers · `2` bad usage.

### Library

```dart
import 'package:atlantic_api/atlantic_api.dart';

final http = AtlanticHttp();
final api = AtlanticAggregator(
  http: http,
  probe: SizeProbe(http: http, mode: SizeProbeMode.sampled),
);

final result = await api.resolve(const MediaRef(type: 'movie', tmdbId: 1368337));

for (final server in result.servers) {
  print('${server.provider} ${server.quality} ${server.size?.human}');
  print(server.url);
}
```

Only want one backend?

```dart
final api = AtlanticAggregator(
  providers: const [BanditProvider(), VixSrcProvider()],
);
```

### HTTP server

```bash
dart run bin/atlantic_server.dart --port 8080
```

```
GET /health
GET /movie/{tmdbId}
GET /tv/{tmdbId}/{season}/{episode}
GET /resolve?url=https://atlantic.bz/title/movie/1368337
GET /resolve?type=tv&id=1399&season=1&episode=1
```

Query params: `size`, `providers` (comma separated), `expand=0`, `concurrency`,
`sample`, `maxVariants`, `title`, `year`.

```bash
curl 'http://127.0.0.1:8080/movie/1368337?size=sampled&providers=Bandit,VixSrc'
```

---

## Output shape

```jsonc
{
  "media": { "type": "movie", "tmdbId": 1368337, "title": "The Odyssey", "year": 2026 },
  "servers": [
    {
      "provider": "Bolo",
      "name": "Bolo",
      "quality": "1080p",
      "kind": "hls",
      "url": "https://api.embedbandit.com/api/stream/…/video/1080p/index.m3u8",
      "subtitles": [ { "url": "…/en.vtt", "lang": "English", "format": "vtt" } ],
      "cached": true,
      "size": {
        "bytes": 5882805198,
        "human": "5.48 GB",
        "durationSeconds": 10355.67,
        "mode": "sampled",
        "probedParts": 10,
        "note": "sampled 10/1724 segments"
      },
      "extra": { "resolution": "1920x1080", "bandwidth": 5949500, "parentUrl": "…" }
    }
  ],
  "subtitles": [ … ],
  "providers": [
    { "provider": "Athena", "servers": 3, "subtitles": 0, "elapsedMs": 412 }
  ],
  "elapsedMs": 4834
}
```

`size.mode` is the honest part: `exact` means every byte was counted, `sampled` means a
spread-out subset was measured, `estimated` means bandwidth math, `unavailable` means the
CDN refused (or the link was an embed page). `providers[]` shows which backends answered
so you can tell "no results" from "provider is down".

---

## Notes & limits

* **The Athenaeum caveat.** The `Athena` source for some titles is a short
  teaser playlist (the Odyssey entry is 64 s / ~500 KB, not the 2 h 52 m feature). The
  API reports what the manifest says — the `durationSeconds` field exposes it.
* **`lightspeed.hls.lol`** (the "AthenaXO" gateway, seen as `/v1/source?provider=light`)
  is proof-of-work gated: it hands out a session, a WASM challenge and 429s a plain
  client. It is deliberately not implemented; the nine backends above cover every link
  the player actually renders.
* **`bandit` (`api.obj2.top`)** and **`Vidbox` (`edge-02.transcode.cfd`)** are regularly
  behind Cloudflare / refused TLS. They show up as `unavailable` with a note instead of
  crashing the run.
* **Legality/ToS:** this talks to third-party hosts the same way the site's own player
  does. Use it for research on your own, not to redistribute anything.
* No dependencies beyond `package:http`.

## Tests

```bash
dart test
```

15 unit tests cover manifest parsing (master/media, byte ranges, encryption, DASH),
target parsing and the model helpers. They run offline against fixtures.

// ignore_for_file: avoid_print

import 'package:atlantic_api/atlantic_api.dart';

/// Minimal end-to-end example.
///
/// ```bash
/// dart run example/resolve.dart 1368337
/// dart run example/resolve.dart https://atlantic.bz/watch/1399/1/1
/// ```
Future<void> main(List<String> args) async {
  final target = args.isEmpty ? '1368337' : args.first;
  final ref = parseTarget(target);
  if (ref == null) {
    print('could not parse "$target"');
    return;
  }

  final http = AtlanticHttp();
  final api = AtlanticAggregator(
    http: http,
    probe: SizeProbe(
      http: http,
      mode: SizeProbeMode.sampled,
      sampleCount: 8,
    ),
  );

  final result = await api.resolve(ref);

  print('${result.title ?? 'TMDB ${ref.tmdbId}'}'
      '${result.year != null ? ' (${result.year})' : ''}'
      '${ref.isTv ? ' S${ref.season}E${ref.episode}' : ''}');
  print('');

  for (final server in result.servers) {
    final size = server.size;
    print('${server.provider.padRight(12)}'
        '${server.quality.padRight(14)}'
        '${(size?.human ?? '?').padRight(10)}'
        '${size?.mode.name ?? '-'}');
    print('  ${server.url}');
    if (server.subtitles.isNotEmpty) {
      final langs = server.subtitles
          .map((s) => s.label ?? s.lang)
          .whereType<String>()
          .toSet()
          .take(6)
          .join(', ');
      print('  subs: $langs (+${server.subtitles.length})');
    }
  }

  print('');
  print('${result.servers.length} links in ${result.elapsedMs} ms');
  api.close();
}

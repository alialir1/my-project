import 'package:atlantic_api/atlantic_api.dart';
import 'package:test/test.dart';

void main() {
  group('parseAttributeList', () {
    test('handles quoted commas', () {
      final attrs = parseAttributeList(
        'BANDWIDTH=1800000,CODECS="avc1.64001f,mp4a.40.2",RESOLUTION=1280x720',
      );
      expect(attrs['BANDWIDTH'], '1800000');
      expect(attrs['CODECS'], 'avc1.64001f,mp4a.40.2');
      expect(attrs['RESOLUTION'], '1280x720');
    });
  });

  group('parseMasterPlaylist', () {
    const master = '''
#EXTM3U
#EXT-X-VERSION:7
#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",NAME="DTS-HD MA 5.1",LANGUAGE="en",DEFAULT=YES,URI="audio/index.m3u8"
#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="English",LANGUAGE="en",URI="subs/en.vtt"
#EXT-X-STREAM-INF:BANDWIDTH=5949500,AVERAGE-BANDWIDTH=4604105,RESOLUTION=1920x1080,CODECS="avc1.640028,mp4a.40.2",AUDIO="audio",SUBTITLES="subs"
video/1080p/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=2511451,RESOLUTION=1280x720,AUDIO="audio"
https://cdn.example/video/720p/index.m3u8
''';

    test('reads variants, resolutions and renditions', () {
      final parsed = parseMasterPlaylist(
          master, Uri.parse('https://cdn.example/hls/master.m3u8'));

      expect(parsed.variants, hasLength(2));
      expect(parsed.variants.first.bandwidth, 5949500);
      expect(parsed.variants.first.averageBandwidth, 4604105);
      expect(parsed.variants.first.qualityLabel, '1080p');
      expect(parsed.variants.first.uri.toString(),
          'https://cdn.example/hls/video/1080p/index.m3u8');

      expect(parsed.variants.last.qualityLabel, '720p');
      expect(parsed.variants.last.uri.toString(),
          'https://cdn.example/video/720p/index.m3u8');

      expect(parsed.audio, hasLength(1));
      expect(parsed.audio.first.name, 'DTS-HD MA 5.1');
      expect(parsed.audio.first.isDefault, isTrue);
      expect(parsed.subtitles, hasLength(1));
    });

    test('classifies playlists', () {
      expect(isMasterPlaylist(master), isTrue);
      expect(looksLikePlaylist(master), isTrue);
      expect(looksLikePlaylist('<html>Access Blocked</html>'), isFalse);
    });
  });

  group('parseMediaPlaylist', () {
    test('sums durations and keeps byte ranges', () {
      const media = '''
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:6
#EXT-X-PLAYLIST-TYPE:VOD
#EXT-X-MAP:URI="init.mp4",BYTERANGE="720@0"
#EXTINF:6.006,
seg-0.ts
#EXTINF:6.006,
https://cdn.example/seg-1.ts
#EXT-X-DISCONTINUITY
#EXTINF:4.5,
#EXT-X-BYTERANGE:1024@2048
seg-2.ts
#EXT-X-ENDLIST
''';
      final parsed = parseMediaPlaylist(
          media, Uri.parse('https://cdn.example/path/index.m3u8'));

      expect(parsed.segments, hasLength(3));
      expect(parsed.duration, closeTo(16.512, 0.001));
      expect(
          parsed.initSegment.toString(), 'https://cdn.example/path/init.mp4');
      expect(parsed.initByterangeLength, 720);
      expect(parsed.segments.last.byterangeLength, 1024);
      expect(parsed.segments.last.byterangeOffset, 2048);
      expect(parsed.encrypted, isFalse);
    });

    test('flags encrypted playlists', () {
      const media = '''
#EXTM3U
#EXT-X-KEY:METHOD=AES-128,URI="key.bin"
#EXTINF:8.0,
seg0.ts
''';
      final parsed = parseMediaPlaylist(
          media, Uri.parse('https://cdn.example/index.m3u8'));
      expect(parsed.encrypted, isTrue);
      expect(parsed.segments, hasLength(1));
    });
  });

  group('parseDashManifest', () {
    test('picks max bandwidth and duration', () {
      const mpd = '''
<MPD mediaPresentationDuration="PT0H1M30.5S">
  <Period><AdaptationSet>
    <Representation id="1" bandwidth="800000" />
    <Representation id="2" bandwidth="2500000" />
  </AdaptationSet></Period>
</MPD>''';
      final info = parseDashManifest(mpd);
      expect(info.bandwidth, 2500000);
      expect(info.durationSeconds, closeTo(90.5, 0.01));
    });
  });

  group('models', () {
    test('human readable sizes', () {
      expect(const SizeInfo(bytes: 512).human, '512 B');
      expect(const SizeInfo(bytes: 1024).human, '1.00 KB');
      expect(const SizeInfo(bytes: 5 * 1024 * 1024).human, '5.00 MB');
      expect(const SizeInfo(bytes: 2473901162).human, '2.30 GB');
      expect(const SizeInfo().human, 'unknown');
    });

    test('stream server json round-trips the essentials', () {
      final server = StreamServer(
        provider: 'Bandit',
        name: 'Bolo',
        quality: '1080p',
        kind: StreamKind.hls,
        url: 'https://example.test/master.m3u8',
        size: const SizeInfo(bytes: 1024, mode: SizeMode.exact, probedParts: 3),
      );
      final json = server.toJson();
      expect(json['provider'], 'Bandit');
      expect(json['kind'], 'hls');
      expect((json['size'] as Map)['human'], '1.00 KB');
    });
  });
}

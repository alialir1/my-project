import 'package:atlantic_api/atlantic_api.dart';
import 'package:test/test.dart';

void main() {
  group('parseTarget', () {
    test('atlantic title urls', () {
      final ref = parseTarget('https://atlantic.bz/title/movie/1368337')!;
      expect(ref.type, 'movie');
      expect(ref.tmdbId, 1368337);
    });

    test('atlantic tv title urls', () {
      final ref = parseTarget('https://atlantic.bz/title/tv/1399')!;
      expect(ref.type, 'tv');
      expect(ref.tmdbId, 1399);
    });

    test('watch urls with and without episode', () {
      final movie = parseTarget('https://atlantic.bz/watch/1368337')!;
      expect(movie.type, 'movie');
      expect(movie.tmdbId, 1368337);

      final episode = parseTarget('https://atlantic.bz/watch/1399/2/5')!;
      expect(episode.type, 'tv');
      expect(episode.season, 2);
      expect(episode.episode, 5);
    });

    test('bare ids and shorthand', () {
      expect(parseTarget('1368337')!.type, 'movie');

      final episode = parseTarget('1399:1:4')!;
      expect(episode.type, 'tv');
      expect(episode.tmdbId, 1399);
      expect(episode.season, 1);
      expect(episode.episode, 4);

      final explicit = parseTarget('tv:1399:3:2')!;
      expect(explicit.season, 3);
      expect(explicit.episode, 2);
    });

    test('rejects nonsense', () {
      expect(parseTarget(''), isNull);
      expect(parseTarget('not-a-title'), isNull);
    });
  });

  group('MediaRef', () {
    test('builds tv paths', () {
      final ref = MediaRef.episode(1399, season: 1, episode: 2);
      expect(ref.toString(), 'tv/1399/1/2');
      expect(ref.tag, '1x2');
    });

    test('movie has no tag', () {
      final ref = MediaRef.movie(603);
      expect(ref.tag, '');
      expect(ref.toString(), 'movie/603');
    });
  });
}

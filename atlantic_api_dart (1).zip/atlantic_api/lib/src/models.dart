/// Data model for everything the Atlantic providers return.
library;

/// What kind of payload a resolved URL points at.
enum StreamKind {
  /// HLS — either a master playlist or a single media playlist.
  hls,

  /// MPEG-DASH manifest (`.mpd`).
  dash,

  /// A single progressive file (`.mp4` / `.mkv`).
  file,

  /// A third-party embed page that has to be opened in a browser.
  embed,

  /// Anything we could not classify.
  unknown;

  static StreamKind parse(Object? raw) {
    switch (raw?.toString().toLowerCase()) {
      case 'hls':
      case 'm3u8':
        return StreamKind.hls;
      case 'dash':
      case 'mpd':
        return StreamKind.dash;
      case 'file':
      case 'mp4':
      case 'mkv':
        return StreamKind.file;
      case 'embed':
      case 'iframe':
        return StreamKind.embed;
      default:
        return StreamKind.unknown;
    }
  }

  String get wire => name;
}

/// A subtitle track served next to a stream.
class SubtitleTrack {
  final String url;
  final String? lang;
  final String? label;
  final String? format;

  const SubtitleTrack({
    required this.url,
    this.lang,
    this.label,
    this.format,
  });

  factory SubtitleTrack.fromJson(Map<String, dynamic> json) => SubtitleTrack(
        url: (json['url'] ?? json['file'] ?? json['src'] ?? '').toString(),
        lang:
            (json['lang'] ?? json['language'] ?? json['langCode'])?.toString(),
        label: (json['label'] ?? json['name'] ?? json['fileName'])?.toString(),
        format: json['type']?.toString() ??
            _guessFormat((json['url'] ?? json['file'])?.toString()),
      );

  static String? _guessFormat(String? url) {
    if (url == null) return null;
    final path = Uri.tryParse(url)?.path ?? url;
    final dot = path.lastIndexOf('.');
    if (dot == -1 || dot == path.length - 1) return null;
    return path.substring(dot + 1).toLowerCase();
  }

  Map<String, dynamic> toJson() => {
        'url': url,
        if (lang != null) 'lang': lang,
        if (label != null) 'label': label,
        if (format != null) 'format': format,
      }.cast<String, dynamic>();

  @override
  String toString() => label ?? lang ?? url;
}

/// Size + metadata for one quality variant inside an HLS master playlist.
class VariantSize {
  final String quality;
  final String? resolution;
  final int? bandwidth;
  final int? bytes;
  final double? durationSeconds;
  final SizeMode mode;

  const VariantSize({
    required this.quality,
    this.resolution,
    this.bandwidth,
    this.bytes,
    this.durationSeconds,
    this.mode = SizeMode.unavailable,
  });

  Map<String, dynamic> toJson() => {
        'quality': quality,
        if (resolution != null) 'resolution': resolution,
        if (bandwidth != null) 'bandwidth': bandwidth,
        'bytes': bytes,
        'mode': mode.name,
        if (durationSeconds != null) 'durationSeconds': durationSeconds,
      };
}

/// Measured (or estimated) size of one stream.
class SizeInfo {
  /// Total size in bytes. `null` when it could not be determined.
  final int? bytes;

  /// Total runtime in seconds, when known.
  final double? durationSeconds;

  /// Declared HLS/DASH bandwidth in bits per second, when advertised.
  final int? bandwidth;

  /// How [bytes] was obtained:
  /// `exact` — every byte-range / content-length was summed,
  /// `sampled` — a subset of segments was measured and extrapolated,
  /// `estimated` — derived from duration × bandwidth,
  /// `unavailable` — the CDN refused to expose a length.
  final SizeMode mode;

  /// Number of segments / parts that actually contributed to [bytes].
  final int probedParts;

  /// Free-form explanation of why a value is missing or is only an estimate.
  final String? note;

  /// Per-quality breakdown, when the URL was an HLS master playlist.
  final List<VariantSize> variants;

  const SizeInfo({
    this.bytes,
    this.durationSeconds,
    this.bandwidth,
    this.mode = SizeMode.unavailable,
    this.probedParts = 0,
    this.note,
    this.variants = const [],
  });

  static const SizeInfo unknown = SizeInfo();

  bool get isKnown => bytes != null && bytes! > 0;

  /// Human readable size, e.g. `2.31 GB`.
  String get human {
    final b = bytes;
    if (b == null) return 'unknown';
    if (b < 1024) return '$b B';
    const units = ['KB', 'MB', 'GB', 'TB'];
    var value = b / 1024;
    var unit = 0;
    while (value >= 1024 && unit < units.length - 1) {
      value /= 1024;
      unit++;
    }
    return '${value.toStringAsFixed(value >= 100 ? 0 : 2)} ${units[unit]}';
  }

  Map<String, dynamic> toJson() => {
        'bytes': bytes,
        'human': human,
        'durationSeconds': durationSeconds,
        if (bandwidth != null) 'bandwidth': bandwidth,
        'mode': mode.name,
        'probedParts': probedParts,
        if (note != null) 'note': note,
        if (variants.isNotEmpty)
          'variants': variants.map((v) => v.toJson()).toList(),
      };
}

enum SizeMode { exact, sampled, estimated, unavailable }

/// One playback server: a provider (optionally a named sub-server), the
/// quality it offers and the URL it hands out.
class StreamServer {
  /// Provider/backend the link came from, e.g. `Bandit`, `Vidbox`, `Vixsrc`.
  final String provider;

  /// Sub-server / file label inside the provider, e.g. `Bolo`, `Atico`.
  final String? name;

  /// Quality label as advertised by the provider (`1080p`, `AUTO`, `Bolo 1080p`).
  final String quality;

  final StreamKind kind;
  final String url;

  /// Audio language for DASH/dub tracks.
  final String? language;

  /// `dub` / `sub` mode for anime-style tracks.
  final String? mode;

  final List<SubtitleTrack> subtitles;

  /// WebVTT thumbnail (sprite) track, when the provider exposes one.
  final String? thumbnailTrack;

  /// Provider-side expiry timestamp for the link.
  final DateTime? expiresAt;

  /// Whether the provider reported the title as cached on its side.
  final bool cached;

  /// Filled in by [SizeProbe]-equipped callers; `null` until probed.
  SizeInfo? size;

  /// Extra provider-specific fields worth keeping around.
  final Map<String, dynamic> extra;

  StreamServer({
    required this.provider,
    required this.url,
    this.name,
    this.quality = 'AUTO',
    this.kind = StreamKind.unknown,
    this.language,
    this.mode,
    this.subtitles = const [],
    this.thumbnailTrack,
    this.expiresAt,
    this.cached = false,
    this.size,
    this.extra = const {},
  });

  /// A stable key for de-duplication across providers.
  String get dedupeKey => '$provider|${name ?? ''}|$quality|$url';

  Map<String, dynamic> toJson() => {
        'provider': provider,
        if (name != null) 'name': name,
        'quality': quality,
        'kind': kind.wire,
        'url': url,
        if (language != null) 'language': language,
        if (mode != null) 'mode': mode,
        if (subtitles.isNotEmpty)
          'subtitles': subtitles.map((s) => s.toJson()).toList(),
        if (thumbnailTrack != null) 'thumbnailTrack': thumbnailTrack,
        if (expiresAt != null) 'expiresAt': expiresAt!.toIso8601String(),
        'cached': cached,
        if (size != null) 'size': size!.toJson(),
        if (extra.isNotEmpty) 'extra': extra,
      };

  @override
  String toString() =>
      '${[provider, if (name != null) name, quality].join(' / ')} → $url';
}

/// What the caller is looking for.
class MediaRef {
  /// `movie` or `tv`.
  final String type;
  final int tmdbId;
  final String? title;
  final int? year;
  final int? season;
  final int? episode;

  const MediaRef({
    required this.type,
    required this.tmdbId,
    this.title,
    this.year,
    this.season,
    this.episode,
  });

  MediaRef.movie(int id, {this.title, this.year})
      : type = 'movie',
        tmdbId = id,
        season = null,
        episode = null;

  MediaRef.episode(
    int id, {
    required this.season,
    required this.episode,
    this.title,
    this.year,
  })  : type = 'tv',
        tmdbId = id;

  bool get isTv => type == 'tv';

  /// `1x04` style tag, empty for movies.
  String get tag => isTv ? '${season ?? 1}x${episode ?? 1}' : '';

  @override
  String toString() =>
      isTv ? 'tv/$tmdbId/${season ?? 1}/${episode ?? 1}' : 'movie/$tmdbId';

  Map<String, dynamic> toJson() => {
        'type': type,
        'tmdbId': tmdbId,
        if (title != null) 'title': title,
        if (year != null) 'year': year,
        if (isTv) 'season': season,
        if (isTv) 'episode': episode,
      };
}

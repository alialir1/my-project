/// File-size measurement.
///
/// None of the providers publish a size field, so sizes are derived from the
/// manifests themselves:
///
/// * `exact`   — every segment's real length is read (HEAD `Content-Length`,
///               or a 1-byte ranged GET and the `Content-Range` total), then
///               summed. Byte-range playlists are resolved without any request.
/// * `sampled` — a spread-out subset of segments is measured and extrapolated
///               over the segment count. Fast, accurate to a couple of percent.
/// * `estimated` — duration × declared bandwidth / 8. No extra requests, very
///               rough.
/// * `none`    — skip probing entirely.
library;

import 'dart:math' as math;

import 'manifest.dart';
import 'models.dart';
import 'net.dart';

enum SizeProbeMode { none, estimated, sampled, exact }

/// Measures the size of resolved stream URLs.
class SizeProbe {
  final AtlanticHttp http;
  final SizeProbeMode mode;

  /// Parallel requests while summing segments.
  final int concurrency;

  /// Segments measured per variant in [SizeProbeMode.sampled].
  final int sampleCount;

  /// If a variant has more segments than this, `exact` degrades to `sampled`
  /// to avoid hammering the CDN hundreds of times.
  final int maxExactSegments;

  /// Replace an HLS master playlist with one entry per quality variant.
  final bool expandVariants;

  /// Only probe the N highest-bandwidth variants of a master playlist
  /// (`0` = all).
  final int maxVariants;

  SizeProbe({
    required this.http,
    this.mode = SizeProbeMode.sampled,
    this.concurrency = 8,
    this.sampleCount = 10,
    this.maxExactSegments = 400,
    this.expandVariants = true,
    this.maxVariants = 0,
  });

  final Map<String, String> _bodyCache = {};

  /// Probes [servers], optionally expanding master playlists into one entry
  /// per variant. Returns the final list (same objects when not expanding).
  Future<List<StreamServer>> probeAll(List<StreamServer> servers) async {
    if (mode == SizeProbeMode.none) return servers;

    final expanded = <StreamServer>[];
    for (final server in servers) {
      if (server.kind == StreamKind.hls && expandVariants) {
        final variants = await _expand(server);
        expanded.addAll(variants);
      } else {
        expanded.add(server);
      }
    }

    await mapPooled(expanded, concurrency, (server, _) async {
      server.size = await _probeServer(server);
      return null;
    });
    return expanded;
  }

  // -------------------------------------------------------------------------
  // Expansion of master playlists
  // -------------------------------------------------------------------------

  Future<List<StreamServer>> _expand(StreamServer server) async {
    final String body;
    try {
      body = await _fetch(server.url);
    } catch (_) {
      return [server];
    }
    if (!isMasterPlaylist(body)) return [server];

    final master = parseMasterPlaylist(body, Uri.parse(server.url));
    if (master.variants.isEmpty) return [server];

    var variants = [...master.variants]
      ..sort((a, b) => (b.bandwidth ?? 0).compareTo(a.bandwidth ?? 0));
    if (maxVariants > 0 && variants.length > maxVariants) {
      variants = variants.sublist(0, maxVariants);
    }

    // Subtitle renditions ride along on every variant.
    final subs = master.subtitles
        .where((r) => r.uri != null)
        .map((r) => SubtitleTrack(
              url: r.uri!.toString(),
              lang: r.language,
              label: r.name,
              format: 'vtt',
            ))
        .toList();

    return variants.map((v) {
      return StreamServer(
        provider: server.provider,
        name: server.name,
        quality: v.qualityLabel,
        kind: StreamKind.hls,
        url: v.uri.toString(),
        language: server.language,
        mode: server.mode,
        subtitles: server.subtitles.isEmpty ? subs : server.subtitles,
        thumbnailTrack: server.thumbnailTrack,
        expiresAt: server.expiresAt,
        cached: server.cached,
        extra: {
          ...server.extra,
          if (v.resolution != null) 'resolution': v.resolution,
          if (v.bandwidth != null) 'bandwidth': v.bandwidth,
          if (v.averageBandwidth != null)
            'averageBandwidth': v.averageBandwidth,
          if (v.codecs != null) 'codecs': v.codecs,
          'parentUrl': server.url,
        },
      );
    }).toList();
  }

  // -------------------------------------------------------------------------
  // Per-kind probing
  // -------------------------------------------------------------------------

  Future<SizeInfo> _probeServer(StreamServer server) async {
    try {
      switch (server.kind) {
        case StreamKind.hls:
          return await _probeHls(server);
        case StreamKind.dash:
          return await _probeDash(server);
        case StreamKind.file:
          return await _probeFile(server);
        case StreamKind.embed:
        case StreamKind.unknown:
          return const SizeInfo(note: 'embed page — no direct file to measure');
      }
    } catch (e) {
      return SizeInfo(note: 'probe failed: $e');
    }
  }

  Future<SizeInfo> _probeHls(StreamServer server) async {
    final body = await _fetch(server.url);

    if (isMasterPlaylist(body)) {
      // Not expanded (or expansion disabled): report every variant and
      // surface the best one at the top level.
      final master = parseMasterPlaylist(body, Uri.parse(server.url));
      final variants = <VariantSize>[];
      var best = const SizeInfo();
      var bestBandwidth = -1;

      for (final v in master.variants) {
        final uri = v.uri.toString();
        final String mediaBody;
        try {
          mediaBody = await _fetch(uri);
        } catch (_) {
          continue;
        }
        final info = await _sizeOfMediaPlaylist(
          mediaBody,
          Uri.parse(uri),
          declaredBandwidth: v.averageBandwidth ?? v.bandwidth,
        );
        variants.add(VariantSize(
          quality: v.qualityLabel,
          resolution: v.resolution,
          bandwidth: v.bandwidth,
          bytes: info.bytes,
          durationSeconds: info.durationSeconds,
          mode: info.mode,
        ));
        final rank = v.bandwidth ?? 0;
        if (rank > bestBandwidth) {
          bestBandwidth = rank;
          best = info;
        }
      }

      final sorted = [...variants]
        ..sort((a, b) => (b.bandwidth ?? 0).compareTo(a.bandwidth ?? 0));
      return SizeInfo(
        bytes: sorted.isEmpty ? null : sorted.first.bytes,
        durationSeconds: sorted.isEmpty ? null : sorted.first.durationSeconds,
        bandwidth: sorted.isEmpty ? null : sorted.first.bandwidth,
        mode: sorted.isEmpty ? SizeMode.unavailable : sorted.first.mode,
        probedParts: best.probedParts,
        note: 'master playlist — value is for '
            '${sorted.isEmpty ? 'n/a' : sorted.first.quality}',
        variants: variants,
      );
    }

    return _sizeOfMediaPlaylist(
      body,
      Uri.parse(server.url),
      declaredBandwidth: server.extra['averageBandwidth'] as int? ??
          server.extra['bandwidth'] as int?,
    );
  }

  Future<SizeInfo> _sizeOfMediaPlaylist(
    String body,
    Uri base, {
    int? declaredBandwidth,
  }) async {
    if (!looksLikePlaylist(body)) {
      return const SizeInfo(note: 'not a playlist (CDN refused the request)');
    }
    final media = parseMediaPlaylist(body, base);
    if (media.segments.isEmpty) {
      return SizeInfo(
        durationSeconds: media.duration,
        bandwidth: declaredBandwidth,
        note: 'empty playlist',
      );
    }
    // Encrypted (#EXT-X-KEY / AES-128) playlists still expose real segment
    // lengths — encryption changes bytes, not Content-Length.
    final encryptionNote =
        media.encrypted ? 'encrypted playlist (#EXT-X-KEY)' : null;

    final averageBandwidth = declaredBandwidth;

    final SizeInfo result;
    switch (mode) {
      case SizeProbeMode.none:
        result = SizeInfo(
          durationSeconds: media.duration,
          bandwidth: declaredBandwidth,
          note: 'probing disabled',
        );
      case SizeProbeMode.estimated:
        result = _estimate(media, averageBandwidth);
      case SizeProbeMode.sampled:
        result = await _measure(media, averageBandwidth, sample: sampleCount);
      case SizeProbeMode.exact:
        if (media.segments.length > maxExactSegments) {
          result = await _measure(media, averageBandwidth,
              sample: sampleCount,
              note: '${media.segments.length} segments > limit '
                  '($maxExactSegments) — sampled instead');
        } else {
          result = await _measure(media, averageBandwidth, sample: 0);
        }
    }

    return encryptionNote == null
        ? result
        : result.copyWithNote(encryptionNote);
  }

  SizeInfo _estimate(HlsMedia media, int? bandwidth) {
    if (bandwidth == null || media.duration <= 0) {
      return SizeInfo(
        durationSeconds: media.duration,
        note: 'no bandwidth declared — cannot estimate',
      );
    }
    final bytes = (media.duration * bandwidth / 8).round();
    return SizeInfo(
      bytes: bytes,
      durationSeconds: media.duration,
      bandwidth: bandwidth,
      mode: SizeMode.estimated,
      note: 'duration × bandwidth',
    );
  }

  Future<SizeInfo> _measure(
    HlsMedia media,
    int? bandwidth, {
    required int sample,
    String? note,
  }) async {
    final segments = media.segments;
    var initBytes = 0;
    if (media.initSegment != null) {
      initBytes = await _lengthOf(media.initSegment!,
              byterangeLength: media.initByterangeLength) ??
          0;
    }

    // Byte-range playlists: every length is in the manifest already.
    if (segments.every((s) => s.byterangeLength != null)) {
      final total =
          segments.fold<int>(initBytes, (a, s) => a + (s.byterangeLength ?? 0));
      return SizeInfo(
        bytes: total,
        durationSeconds: media.duration,
        bandwidth: bandwidth,
        mode: SizeMode.exact,
        probedParts: segments.length,
        note: 'byte-range playlist',
      );
    }

    final List<HlsSegment> targets;
    final bool extrapolate;
    if (sample <= 0 || sample >= segments.length) {
      targets = segments;
      extrapolate = false;
    } else {
      // Spread the sample evenly across the timeline.
      final step = segments.length / sample;
      targets = [
        for (var i = 0; i < sample; i++)
          segments[(i * step).floor().clamp(0, segments.length - 1)]
      ];
      extrapolate = true;
    }

    final lengths = await mapPooled(
      targets,
      concurrency,
      (seg, _) => _lengthOf(seg.uri, byterangeLength: seg.byterangeLength),
    );

    final known = lengths.whereType<int>().toList();
    if (known.isEmpty) {
      return _estimate(media, bandwidth).copyWithNote(
        'CDN hid every Content-Length — fell back to bandwidth estimate',
      );
    }

    final knownSum = known.fold<int>(0, (a, b) => a + b);

    // Too many misses to trust an extrapolation.
    if (known.length < (targets.length / 2)) {
      final estimate = _estimate(media, bandwidth);
      if (estimate.isKnown) {
        return estimate.copyWithNote(
          'only ${known.length}/${targets.length} segments measurable — '
          'bandwidth estimate used',
        );
      }
      return SizeInfo(
        bytes: (knownSum / known.length * segments.length).round() + initBytes,
        durationSeconds: media.duration,
        bandwidth: bandwidth,
        mode: SizeMode.sampled,
        probedParts: known.length,
        note: 'only ${known.length}/${targets.length} segments measurable — '
            'low confidence',
      );
    }

    var total = initBytes + knownSum;
    if (extrapolate) {
      final avg = knownSum / known.length;
      total = initBytes + (avg * segments.length).round();
    } else if (known.length < targets.length) {
      // Partial data in exact mode: scale up for the ones that failed.
      final avg = knownSum / known.length;
      total = initBytes + (avg * segments.length).round();
      return SizeInfo(
        bytes: total,
        durationSeconds: media.duration,
        bandwidth: bandwidth,
        mode: SizeMode.sampled,
        probedParts: known.length,
        note: '${targets.length - known.length}/${targets.length} segments '
            'had no length — extrapolated',
      );
    }

    return SizeInfo(
      bytes: total,
      durationSeconds: media.duration,
      bandwidth: bandwidth,
      mode: extrapolate ? SizeMode.sampled : SizeMode.exact,
      probedParts: known.length,
      note: note ??
          (extrapolate
              ? 'sampled ${known.length}/${segments.length} segments'
              : null),
    );
  }

  Future<SizeInfo> _probeDash(StreamServer server) async {
    final body = await _fetch(server.url);
    if (!body.contains('<MPD') && !body.contains('<mpd')) {
      return const SizeInfo(note: 'not a DASH manifest');
    }
    final info = parseDashManifest(body);
    if (mode == SizeProbeMode.estimated || mode == SizeProbeMode.none) {
      return _estimate(
        HlsMedia(segments: const [], duration: info.durationSeconds ?? 0),
        info.bandwidth,
      );
    }
    // DASH segment lists are template-driven and vary wildly; bandwidth ×
    // duration is the reliable figure without fetching thousands of parts.
    return _estimate(
      HlsMedia(segments: const [], duration: info.durationSeconds ?? 0),
      info.bandwidth,
    ).copyWithNote('DASH — derived from MPD bandwidth × duration');
  }

  Future<SizeInfo> _probeFile(StreamServer server) async {
    final length = await _lengthOf(Uri.parse(server.url));
    if (length == null) {
      return const SizeInfo(note: 'no Content-Length available');
    }
    return SizeInfo(bytes: length, mode: SizeMode.exact, probedParts: 1);
  }

  // -------------------------------------------------------------------------
  // Low-level helpers
  // -------------------------------------------------------------------------

  Future<String> _fetch(String url) async {
    final cached = _bodyCache[url];
    if (cached != null) return cached;
    final res = await http.get(Uri.parse(url));
    final body = res.body;
    _bodyCache[url] = body;
    return body;
  }

  /// Real byte length of one segment / file.
  Future<int?> _lengthOf(Uri uri, {int? byterangeLength}) async {
    if (byterangeLength != null && byterangeLength > 0) return byterangeLength;
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        final res = await http.headOrRange(uri.toString());
        final range = res.headers['content-range'];
        if (range != null) {
          final slash = range.lastIndexOf('/');
          if (slash != -1) {
            final total = int.tryParse(range.substring(slash + 1).trim());
            if (total != null && total > 0) return total;
          }
        }
        final len = int.tryParse(res.headers['content-length'] ?? '');
        if (len != null && len > 0) return len;
      } catch (_) {
        // retry once — these CDNs throw sporadic 403s under load
      }
      await Future<void>.delayed(Duration(milliseconds: 120 * (attempt + 1)));
    }
    return null;
  }
}

extension on SizeInfo {
  SizeInfo copyWithNote(String extra) => SizeInfo(
        bytes: bytes,
        durationSeconds: durationSeconds,
        bandwidth: bandwidth,
        mode: mode,
        probedParts: probedParts,
        note: note == null ? extra : '$note · $extra',
        variants: variants,
      );
}

/// Convenience used by the CLI: clamp a user-supplied percentage.
double pct(int part, int whole) =>
    whole == 0 ? 0 : math.min(100, (part / whole * 100)).toDouble();

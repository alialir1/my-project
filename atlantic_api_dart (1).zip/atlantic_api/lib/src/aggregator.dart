/// Fans out to every provider, merges the results and attaches file sizes.
library;

import 'dart:async';

import 'models.dart';
import 'net.dart';
import 'probe.dart';
import 'providers.dart';

/// Per-provider outcome, handy for debugging which backend is down today.
class ProviderReport {
  final String provider;
  final int servers;
  final int subtitles;
  final String? error;
  final int elapsedMs;

  const ProviderReport({
    required this.provider,
    required this.servers,
    required this.subtitles,
    required this.elapsedMs,
    this.error,
  });

  bool get ok => error == null;

  Map<String, dynamic> toJson() => {
        'provider': provider,
        'servers': servers,
        'subtitles': subtitles,
        'elapsedMs': elapsedMs,
        if (error != null) 'error': error,
      };
}

/// Everything resolved for one title/episode.
class AggregateResult {
  final MediaRef ref;
  final String? title;
  final int? year;
  final List<StreamServer> servers;
  final List<SubtitleTrack> subtitles;
  final List<ProviderReport> providers;
  final int elapsedMs;

  const AggregateResult({
    required this.ref,
    required this.servers,
    required this.subtitles,
    required this.providers,
    required this.elapsedMs,
    this.title,
    this.year,
  });

  bool get isEmpty => servers.isEmpty;

  Map<String, dynamic> toJson() => {
        'media': {
          ...ref.toJson(),
          if (title != null) 'title': title,
          if (year != null) 'year': year,
        },
        'servers': servers.map((s) => s.toJson()).toList(),
        'subtitles': subtitles.map((s) => s.toJson()).toList(),
        'providers': providers.map((p) => p.toJson()).toList(),
        'elapsedMs': elapsedMs,
      };
}

class AtlanticAggregator {
  final AtlanticHttp http;
  final List<StreamProvider> providers;
  final SizeProbe? probe;

  AtlanticAggregator({
    AtlanticHttp? http,
    List<StreamProvider>? providers,
    this.probe,
  })  : http = http ?? AtlanticHttp(),
        providers = providers ?? defaultProviders();

  /// Resolves [ref] against every provider.
  ///
  /// Providers that need a title (Dizipal, FSOnline, Dash) run in a second wave
  /// once a title has been learned from the first wave, so callers only have to
  /// supply a TMDB id.
  Future<AggregateResult> resolve(MediaRef ref) async {
    final started = DateTime.now().millisecondsSinceEpoch;
    final reports = <ProviderReport>[];
    final servers = <StreamServer>[];
    final subs = <SubtitleTrack>[];
    String? title = ref.title;
    int? year = ref.year;

    Future<void> run(StreamProvider provider, MediaRef target) async {
      final t0 = DateTime.now().millisecondsSinceEpoch;
      try {
        final result = await provider.resolve(target, http);
        servers.addAll(result.servers.where((s) => s.url.isNotEmpty));
        subs.addAll(result.subtitles.where((s) => s.url.isNotEmpty));
        title ??= result.title;
        year ??= result.year;
        reports.add(ProviderReport(
          provider: provider.name,
          servers: result.servers.length,
          subtitles: result.subtitles.length,
          elapsedMs: DateTime.now().millisecondsSinceEpoch - t0,
          error: result.error,
        ));
      } catch (e) {
        reports.add(ProviderReport(
          provider: provider.name,
          servers: 0,
          subtitles: 0,
          elapsedMs: DateTime.now().millisecondsSinceEpoch - t0,
          error: e.toString(),
        ));
      }
    }

    final needsTitle = providers.where((p) => p.requiresTitle).toList();
    final immediate = providers.where((p) => !p.requiresTitle).toList();

    // Wave 1 — everything that only needs the TMDB id.
    await Future.wait(immediate.map((p) => run(p, ref)));

    // Wave 2 — the title-dependent backends.
    if (needsTitle.isNotEmpty) {
      final enriched = MediaRef(
        type: ref.type,
        tmdbId: ref.tmdbId,
        title: title,
        year: year,
        season: ref.season,
        episode: ref.episode,
      );
      await Future.wait(needsTitle.map((p) => run(p, enriched)));
    }

    // Deduplicate identical links coming from different sub-servers.
    final byKey = <String, StreamServer>{};
    for (final server in servers) {
      byKey.putIfAbsent(server.dedupeKey, () => server);
    }
    final merged = byKey.values.toList();

    final subByKey = <String, SubtitleTrack>{};
    for (final s in subs) {
      subByKey.putIfAbsent('${s.lang ?? s.label ?? ''}|${s.url}', () => s);
    }

    final probe = this.probe;
    final finalServers = probe == null ? merged : await probe.probeAll(merged);

    return AggregateResult(
      ref: ref,
      title: title,
      year: year,
      servers: finalServers,
      subtitles: subByKey.values.toList(),
      providers: reports,
      elapsedMs: DateTime.now().millisecondsSinceEpoch - started,
    );
  }

  void close() => http.close();
}

/// Parses `atlantic.bz` style URLs and bare ids into a [MediaRef].
///
/// Accepts:
///   * `https://atlantic.bz/title/movie/1368337`
///   * `https://atlantic.bz/watch/1368337`
///   * `https://atlantic.bz/watch/1399/1/1`
///   * `https://atlantic.bz/title/tv/1399`
///   * `movie:1368337`, `tv:1399:1:1`
///   * `1368337` (defaults to movie)
MediaRef? parseTarget(String input) {
  final text = input.trim();
  if (text.isEmpty) return null;

  final uri = Uri.tryParse(text);
  if (uri != null && uri.hasScheme) {
    final segments = uri.pathSegments.where((s) => s.isNotEmpty).toList();
    if (segments.length >= 3 && segments[0] == 'title') {
      final type = segments[1];
      final id = int.tryParse(segments[2]);
      if (id != null) {
        return MediaRef(type: type == 'tv' ? 'tv' : 'movie', tmdbId: id);
      }
    }
    if (segments.length >= 2 && segments[0] == 'watch') {
      final id = int.tryParse(segments[1]);
      if (id != null) {
        if (segments.length >= 4) {
          return MediaRef(
            type: 'tv',
            tmdbId: id,
            season: int.tryParse(segments[2]) ?? 1,
            episode: int.tryParse(segments[3]) ?? 1,
          );
        }
        return MediaRef(type: 'movie', tmdbId: id);
      }
    }
    if (segments.length >= 2 &&
        segments[0] == 'embed' &&
        segments.length >= 3) {
      final id = int.tryParse(segments[2]);
      if (id != null) {
        if (segments[1] == 'tv' && segments.length >= 5) {
          return MediaRef(
            type: 'tv',
            tmdbId: id,
            season: int.tryParse(segments[3]) ?? 1,
            episode: int.tryParse(segments[4]) ?? 1,
          );
        }
        return MediaRef(type: 'movie', tmdbId: id);
      }
    }
  }

  final parts = text.split(RegExp(r'[:/]')).where((s) => s.isNotEmpty).toList();
  if (parts.isEmpty) return null;

  // Bare id, or `1399:1:1` shorthand for a TV episode.
  final leadingId = int.tryParse(parts[0]);
  if (leadingId != null) {
    if (parts.length == 1) return MediaRef(type: 'movie', tmdbId: leadingId);
    return MediaRef(
      type: 'tv',
      tmdbId: leadingId,
      season: int.tryParse(parts[1]) ?? 1,
      episode: parts.length > 2 ? int.tryParse(parts[2]) ?? 1 : 1,
    );
  }

  if (parts.length == 1) return null;
  final type = parts[0].toLowerCase() == 'tv' ? 'tv' : 'movie';
  final id = int.tryParse(parts[1]);
  if (id == null) return null;
  if (type == 'tv') {
    return MediaRef(
      type: 'tv',
      tmdbId: id,
      season: parts.length > 2 ? int.tryParse(parts[2]) ?? 1 : 1,
      episode: parts.length > 3 ? int.tryParse(parts[3]) ?? 1 : 1,
    );
  }
  return MediaRef(type: 'movie', tmdbId: id);
}

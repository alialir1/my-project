/// One class per backend the site talks to.
///
/// Each provider is independent: it can fail, time out or 404 without taking
/// the others down. The aggregator fans out and merges whatever comes back.
library;

import 'dart:async';

import 'models.dart';
import 'net.dart';

/// What a single provider returned.
class ProviderResult {
  final String provider;
  final List<StreamServer> servers;
  final List<SubtitleTrack> subtitles;

  /// Providers sometimes hand back the canonical title/year for a TMDB id,
  /// which unblocks the providers that require a title.
  final String? title;
  final int? year;
  final String? error;

  const ProviderResult({
    required this.provider,
    this.servers = const [],
    this.subtitles = const [],
    this.title,
    this.year,
    this.error,
  });

  bool get isEmpty => servers.isEmpty && subtitles.isEmpty;
}

/// Base class for a playback backend.
abstract class StreamProvider {
  const StreamProvider();

  /// Stable id used in output and for enabling/disabling providers.
  String get name;

  /// Human-friendly label shown in the site's server picker.
  String get label => name;

  /// Whether this provider can only be queried when [MediaRef.title] is known.
  bool get requiresTitle => false;

  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http);

  ProviderResult empty({String? error}) =>
      ProviderResult(provider: name, error: error);
}

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

String _typeOf(MediaRef ref) => ref.isTv ? 'tv' : 'movie';

Map<String, dynamic>? _asMap(Object? value) =>
    value is Map<Object?, Object?> ? value.cast<String, dynamic>() : null;

List<Map<String, dynamic>> _asMapList(Object? value) {
  if (value is! List) return const [];
  return value
      .whereType<Map<Object?, Object?>>()
      .map((e) => e.cast<String, dynamic>())
      .toList();
}

List<SubtitleTrack> _subs(Object? value) =>
    _asMapList(value).map(SubtitleTrack.fromJson).toList();

DateTime? _parseDate(Object? value) =>
    value == null ? null : DateTime.tryParse(value.toString());

/// Turns `{ "<name>": {...} }` (Vidbox / Vixsrc / Dizipal shape) into servers.
List<StreamServer> _serversFromSourceMap(
  String provider,
  Object? sourceMap, {
  List<SubtitleTrack> subtitles = const [],
}) {
  final map = _asMap(sourceMap);
  if (map == null) return const [];
  final out = <StreamServer>[];
  map.forEach((key, raw) {
    final data = _asMap(raw);
    if (data == null) return;
    final url = data['url']?.toString() ?? data['file']?.toString();
    if (url == null || url.isEmpty) return;
    out.add(StreamServer(
      provider: data['server']?.toString() ?? provider,
      name: key == provider ? null : key,
      quality:
          data['quality']?.toString() ?? data['label']?.toString() ?? 'AUTO',
      kind: StreamKind.parse(data['type'] ?? data['kind']),
      url: url,
      subtitles: subtitles,
      expiresAt: _parseDate(data['expiresAt']),
    ));
  });
  return out;
}

// ---------------------------------------------------------------------------
// Athena — the site's own manual catalogue (cdn.hls.lol)
// ---------------------------------------------------------------------------

/// `cdn.hls.lol/content/...` — the curated "Athena" catalogue. Doubles as a
/// title resolver because it echoes back the canonical title and year.
class AthenaProvider extends StreamProvider {
  const AthenaProvider();

  @override
  String get name => 'Athena';

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final path = ref.isTv
        ? '/content/tv/${ref.tmdbId}/${ref.season ?? 1}/${ref.episode ?? 1}'
        : '/content/movie/${ref.tmdbId}';
    final data =
        _asMap(await http.getJson(Uri.parse('https://cdn.hls.lol$path')));
    if (data == null || data['found'] != true) return empty();

    final url = data['url']?.toString();
    if (url == null || url.isEmpty) return empty();

    return ProviderResult(
      provider: name,
      title: data['title']?.toString(),
      servers: [
        StreamServer(
          provider: name,
          quality: 'AUTO',
          kind: StreamKind.parse(data['type'] ?? 'hls'),
          url: url,
          extra: {
            if (data['source'] != null) 'source': data['source'],
            if (data['updated_at'] != null) 'updatedAt': data['updated_at'],
          },
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Vidbox — stream.hls.lol/vidbox
// ---------------------------------------------------------------------------

class VidboxProvider extends StreamProvider {
  const VidboxProvider();

  @override
  String get name => 'Vidbox';

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final uri =
        Uri.parse('https://stream.hls.lol/vidbox').replace(queryParameters: {
      'tmdbId': '${ref.tmdbId}',
      'type': _typeOf(ref),
      if (ref.isTv) 'season': '${ref.season ?? 1}',
      if (ref.isTv) 'episode': '${ref.episode ?? 1}',
    });
    final data = _asMap(await http.getJson(uri));
    if (data == null) return empty();
    final servers = _serversFromSourceMap(name, data['sources']);
    return ProviderResult(provider: name, servers: servers);
  }
}

// ---------------------------------------------------------------------------
// Play4U — stream.hls.lol/play4u (embed player)
// ---------------------------------------------------------------------------

class Play4uProvider extends StreamProvider {
  const Play4uProvider();

  @override
  String get name => 'Play4U';

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final uri =
        Uri.parse('https://stream.hls.lol/play4u').replace(queryParameters: {
      'tmdbId': '${ref.tmdbId}',
      'type': _typeOf(ref),
      if (ref.isTv) 'season': '${ref.season ?? 1}',
      if (ref.isTv) 'episode': '${ref.episode ?? 1}',
    });
    final data = _asMap(await http.getJson(uri));
    if (data == null) return empty();
    final url = data['url']?.toString();
    if (url == null || url.isEmpty) return empty();

    final qualities =
        (data['qualities'] as List?)?.map((e) => e.toString()).toList() ??
            const [];
    final languages =
        (data['languages'] as List?)?.map((e) => e.toString()).toList() ??
            const [];

    return ProviderResult(
      provider: name,
      servers: [
        StreamServer(
          provider: name,
          quality: qualities.isEmpty ? 'AUTO' : qualities.join(' / '),
          kind: StreamKind.embed,
          url: url,
          extra: {
            'qualities': qualities,
            'languages': languages,
          },
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Prism — stream.hls.lol/mbox (DASH tracks, one per audio language)
// ---------------------------------------------------------------------------

class PrismProvider extends StreamProvider {
  const PrismProvider();

  @override
  String get name => 'Prism';

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final uri =
        Uri.parse('https://stream.hls.lol/mbox').replace(queryParameters: {
      'tmdbId': '${ref.tmdbId}',
      'type': _typeOf(ref),
      if (ref.isTv) 'season': '${ref.season ?? 1}',
      if (ref.isTv) 'episode': '${ref.episode ?? 1}',
    });
    final data = _asMap(await http.getJson(uri));
    if (data == null) return empty();

    final subtitles = _subs(data['subtitles']);
    final expires = _parseDate(data['expiresAt']);
    final serverName = data['server']?.toString() ?? name;

    final servers = _asMapList(data['tracks'])
        .map((t) {
          final lang = t['lang']?.toString();
          return StreamServer(
            provider: serverName,
            name: lang,
            quality: t['quality']?.toString() ?? 'AUTO',
            kind: StreamKind.parse(t['kind'] ?? 'dash'),
            url: t['url']?.toString() ?? '',
            language: lang,
            mode: t['mode']?.toString(),
            subtitles: subtitles,
            expiresAt: expires,
            extra: {if (t['id'] != null) 'trackId': t['id']},
          );
        })
        .where((s) => s.url.isNotEmpty)
        .toList();

    return ProviderResult(
        provider: name, servers: servers, subtitles: subtitles);
  }
}

// ---------------------------------------------------------------------------
// Bandit — pal.hls.lol/bandit/streams
// ---------------------------------------------------------------------------

class BanditProvider extends StreamProvider {
  const BanditProvider();

  @override
  String get name => 'Bandit';

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final uri = Uri.parse('https://pal.hls.lol/bandit/streams')
        .replace(queryParameters: {
      'type': _typeOf(ref),
      'tmdb': '${ref.tmdbId}',
      if (ref.isTv) 'season': '${ref.season ?? 1}',
      if (ref.isTv) 'episode': '${ref.episode ?? 1}',
    });
    final data = _asMap(await http.getJson(uri));
    if (data == null || data['found'] != true) return empty();

    final servers = <StreamServer>[];
    for (final server in _asMapList(data['servers'])) {
      final serverName = server['name']?.toString() ?? name;
      final cached = server['cached'] == true;
      for (final stream in _asMapList(server['streams'])) {
        final url = stream['url']?.toString();
        if (url == null || url.isEmpty) continue;
        servers.add(StreamServer(
          provider: serverName,
          name: serverName,
          quality: stream['quality']?.toString() ?? 'AUTO',
          kind: StreamKind.hls,
          url: url,
          subtitles: _subs(stream['subtitles']),
          thumbnailTrack: stream['thumbnails']?.toString(),
          cached: cached,
          extra: {if (server['name'] != null) 'group': server['name']},
        ));
      }
    }
    return ProviderResult(provider: name, servers: servers);
  }
}

// ---------------------------------------------------------------------------
// VixSrc — it.hls.lol/resolve
// ---------------------------------------------------------------------------

class VixSrcProvider extends StreamProvider {
  const VixSrcProvider();

  @override
  String get name => 'VixSrc';

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final uri =
        Uri.parse('https://it.hls.lol/resolve').replace(queryParameters: {
      'tmdbId': '${ref.tmdbId}',
      'type': _typeOf(ref),
      if (ref.isTv) 'season': '${ref.season ?? 1}',
      if (ref.isTv) 'episode': '${ref.episode ?? 1}',
    });
    final data = _asMap(await http.getJson(uri));
    if (data == null || data['found'] != true) return empty();

    final subtitles = _subs(data['subtitles']);
    return ProviderResult(
      provider: name,
      subtitles: subtitles,
      servers:
          _serversFromSourceMap(name, data['sources'], subtitles: subtitles),
    );
  }
}

// ---------------------------------------------------------------------------
// Dizipal — pal.hls.lol/resolve (needs a title)
// ---------------------------------------------------------------------------

class DizipalProvider extends StreamProvider {
  const DizipalProvider();

  @override
  String get name => 'Dizipal';

  @override
  bool get requiresTitle => true;

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final title = ref.title;
    if (title == null || title.trim().isEmpty) {
      return empty(error: 'title required');
    }
    final uri =
        Uri.parse('https://pal.hls.lol/resolve').replace(queryParameters: {
      'tmdbId': '${ref.tmdbId}',
      'type': _typeOf(ref),
      'title': title,
      if (ref.year != null) 'year': '${ref.year}',
      if (ref.isTv) 'season': '${ref.season ?? 1}',
      if (ref.isTv) 'episode': '${ref.episode ?? 1}',
    });
    final data = _asMap(await http.getJson(uri));
    if (data == null || data['found'] != true) return empty();

    final subtitles = _subs(data['subtitles']);
    return ProviderResult(
      provider: name,
      subtitles: subtitles,
      servers:
          _serversFromSourceMap(name, data['sources'], subtitles: subtitles),
    );
  }
}

// ---------------------------------------------------------------------------
// Shegu — shegu.hls.lol/resolve
// ---------------------------------------------------------------------------

class SheguProvider extends StreamProvider {
  const SheguProvider();

  @override
  String get name => 'Shegu';

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final path = ref.isTv
        ? 'https://shegu.hls.lol/resolve/tv/${ref.tmdbId}/${ref.season ?? 1}/${ref.episode ?? 1}'
        : 'https://shegu.hls.lol/resolve/movie/${ref.tmdbId}';
    final data = _asMap(await http.getJson(Uri.parse(path)));
    if (data == null || data['found'] != true) {
      return empty(error: data?['error']?.toString());
    }
    final subtitles = _subs(data['subtitles']);
    var servers =
        _serversFromSourceMap(name, data['sources'], subtitles: subtitles);
    if (servers.isEmpty && data['url'] != null) {
      servers = [
        StreamServer(
          provider: name,
          quality: 'AUTO',
          kind: StreamKind.parse(data['type'] ?? 'hls'),
          url: data['url'].toString(),
          subtitles: subtitles,
        ),
      ];
    }
    return ProviderResult(
        provider: name, servers: servers, subtitles: subtitles);
  }
}

// ---------------------------------------------------------------------------
// FSOnline — pal.hls.lol/fs/embed (embed pages)
// ---------------------------------------------------------------------------

class FsOnlineProvider extends StreamProvider {
  const FsOnlineProvider();

  @override
  String get name => 'FSOnline';

  @override
  bool get requiresTitle => true;

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final title = ref.title;
    if (title == null || title.trim().isEmpty) {
      return empty(error: 'title required');
    }
    final params = <String, String>{
      'title': title,
      'type': _typeOf(ref),
      if (ref.year != null) 'year': '${ref.year}',
      if (ref.isTv) 'seasonId': '${ref.season ?? 1}',
      if (ref.isTv) 'episodeId': '${ref.episode ?? 1}',
    };
    final uri = Uri.parse('https://pal.hls.lol/fs/embed')
        .replace(queryParameters: params);
    final data = _asMap(await http.getJson(uri));
    if (data == null || data['found'] != true) return empty();

    final page = data['page']?.toString();
    final servers = _asMapList(data['embeds'])
        .map((e) {
          return StreamServer(
            provider: name,
            name: e['name']?.toString(),
            quality: 'AUTO',
            kind: StreamKind.embed,
            url: e['url']?.toString() ?? '',
            extra: {if (page != null) 'page': page},
          );
        })
        .where((s) => s.url.isNotEmpty)
        .toList();

    return ProviderResult(provider: name, servers: servers);
  }
}

// ---------------------------------------------------------------------------
// Dash — dash.hls.lol/resolve (flaky upstream, kept because it sometimes hits)
// ---------------------------------------------------------------------------

class DashProvider extends StreamProvider {
  const DashProvider();

  @override
  String get name => 'Dash';

  @override
  bool get requiresTitle => true;

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final title = ref.title;
    if (title == null || title.trim().isEmpty) {
      return empty(error: 'title required');
    }
    final uri =
        Uri.parse('https://dash.hls.lol/resolve').replace(queryParameters: {
      'type': _typeOf(ref),
      'tmdbId': '${ref.tmdbId}',
      'title': title,
      if (ref.year != null) 'year': '${ref.year}',
      if (ref.isTv) 'season': '${ref.season ?? 1}',
      if (ref.isTv) 'episode': '${ref.episode ?? 1}',
    });
    final data = _asMap(await http.getJson(uri));
    if (data == null || data['found'] != true) return empty();
    final subtitles = _subs(data['subtitles']);
    return ProviderResult(
      provider: name,
      subtitles: subtitles,
      servers:
          _serversFromSourceMap(name, data['sources'], subtitles: subtitles),
    );
  }
}

// ---------------------------------------------------------------------------
// Subtitles — two extra endpoints the site uses only for captions
// ---------------------------------------------------------------------------

/// `natsuki.hls.lol/subs` + `sub.vdrk.site` — subtitle-only providers.
class SubtitleProvider extends StreamProvider {
  const SubtitleProvider();

  @override
  String get name => 'Subtitles';

  @override
  Future<ProviderResult> resolve(MediaRef ref, AtlanticHttp http) async {
    final out = <SubtitleTrack>[];

    Future<void> tryNatsuki() async {
      try {
        final uri = Uri.parse('https://natsuki.hls.lol/subs').replace(
          queryParameters: {'tmdbId': '${ref.tmdbId}', 'type': _typeOf(ref)},
        );
        final data = await http.getJson(uri);
        out.addAll(_subs(data));
        final map = _asMap(data);
        if (map != null) out.addAll(_subs(map['subtitles']));
      } catch (_) {}
    }

    Future<void> tryVdrk() async {
      try {
        final path = ref.isTv
            ? 'https://sub.vdrk.site/v1/tv/${ref.tmdbId}/${ref.season ?? 1}/${ref.episode ?? 1}'
            : 'https://sub.vdrk.site/v1/movie/${ref.tmdbId}';
        final data = await http.getJson(Uri.parse(path));
        out.addAll(_subs(data));
      } catch (_) {}
    }

    await Future.wait([tryNatsuki(), tryVdrk()]);
    final deduped = <String, SubtitleTrack>{};
    for (final s in out) {
      if (s.url.isEmpty) continue;
      deduped.putIfAbsent('${s.lang ?? s.label ?? ''}|${s.url}', () => s);
    }
    return ProviderResult(provider: name, subtitles: deduped.values.toList());
  }
}

/// The full provider set, in the order the site probes them.
List<StreamProvider> defaultProviders() => const [
      AthenaProvider(),
      VidboxProvider(),
      Play4uProvider(),
      PrismProvider(),
      BanditProvider(),
      VixSrcProvider(),
      DizipalProvider(),
      SheguProvider(),
      FsOnlineProvider(),
      DashProvider(),
    ];

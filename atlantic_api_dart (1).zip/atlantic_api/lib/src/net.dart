/// Thin HTTP layer: one place for the headers every provider expects,
/// timeouts, retries and JSON decoding.
library;

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

/// Default browser-ish identity. Providers block the default Dart UA.
const String kUserAgent =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

/// The site the providers were built for. Most of them check `Referer`.
const String kSiteOrigin = 'https://atlantic.bz';

class HttpFailure implements Exception {
  final String url;
  final int? status;
  final String message;

  HttpFailure(this.url, this.status, this.message);

  @override
  String toString() => 'HttpFailure($status) $url — $message';
}

class AtlanticHttp {
  final http.Client _client;
  final Duration timeout;
  final int retries;

  /// Extra headers merged into every request (useful for proxies/CDNs that
  /// want a cookie or an auth header).
  final Map<String, String> extraHeaders;

  AtlanticHttp({
    http.Client? client,
    this.timeout = const Duration(seconds: 20),
    this.retries = 2,
    this.extraHeaders = const {},
  }) : _client = client ?? http.Client();

  Map<String, String> _headers({bool json = false}) => {
        'User-Agent': kUserAgent,
        'Accept': json ? 'application/json, text/plain, */*' : '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': '$kSiteOrigin/',
        'Origin': kSiteOrigin,
        if (json) 'Content-Type': 'application/json',
        ...extraHeaders,
      };

  Future<http.Response> get(Uri uri, {bool json = false}) async {
    Object? lastError;
    for (var attempt = 0; attempt <= retries; attempt++) {
      try {
        final res = await _client
            .get(uri, headers: _headers(json: json))
            .timeout(timeout);
        if (res.statusCode >= 500 || res.statusCode == 429) {
          lastError = HttpFailure(uri.toString(), res.statusCode, 'retryable');
          await Future<void>.delayed(
              Duration(milliseconds: 250 * (attempt + 1)));
          continue;
        }
        return res;
      } on TimeoutException {
        lastError = HttpFailure(uri.toString(), null, 'timeout');
      } catch (e) {
        lastError = HttpFailure(uri.toString(), null, e.toString());
      }
      await Future<void>.delayed(Duration(milliseconds: 250 * (attempt + 1)));
    }
    throw lastError is HttpFailure
        ? lastError
        : HttpFailure(uri.toString(), null, lastError.toString());
  }

  /// GET + JSON decode. Returns `null` for 404 / empty bodies instead of
  /// throwing, because half the providers answer 404 with `{"error":...}`.
  Future<dynamic> getJson(Uri uri) async {
    final res = await get(uri, json: true);
    if (res.statusCode == 404) {
      try {
        return jsonDecode(res.body);
      } catch (_) {
        return null;
      }
    }
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw HttpFailure(uri.toString(), res.statusCode, res.body);
    }
    final body = res.body.trim();
    if (body.isEmpty) return null;
    try {
      return jsonDecode(body);
    } on FormatException {
      throw HttpFailure(uri.toString(), res.statusCode, 'invalid json');
    }
  }

  /// HEAD, falling back to a 1-byte ranged GET when the origin refuses HEAD.
  Future<http.Response> headOrRange(String url) async {
    final uri = Uri.parse(url);
    try {
      final res = await _client.head(uri, headers: _headers()).timeout(timeout);
      if (res.statusCode == 200 && res.headers['content-length'] != null) {
        return res;
      }
    } catch (_) {
      // fall through to ranged GET
    }
    final req = http.Request('GET', uri);
    req.headers.addAll({..._headers(), 'Range': 'bytes=0-0'});
    final streamed = await _client.send(req).timeout(timeout);
    final res = await http.Response.fromStream(streamed);
    return res;
  }

  void close() => _client.close();
}

/// Runs [tasks] with at most [concurrency] in flight, preserving order.
Future<List<R>> mapPooled<T, R>(
  Iterable<T> items,
  int concurrency,
  Future<R> Function(T item, int index) run,
) async {
  final list = items.toList();
  final results = List<R?>.filled(list.length, null);
  var cursor = 0;

  Future<void> worker() async {
    while (true) {
      final index = cursor++;
      if (index >= list.length) return;
      results[index] = await run(list[index], index);
    }
  }

  final workers = List.generate(
    concurrency < 1
        ? 1
        : (concurrency > list.length ? list.length : concurrency),
    (_) => worker(),
  );
  await Future.wait(workers);
  return results.cast<R>();
}

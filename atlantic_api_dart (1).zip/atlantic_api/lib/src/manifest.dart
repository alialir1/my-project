/// Minimal HLS / DASH manifest parsing.
///
/// Only what is needed to expose stream metadata and to compute file sizes:
/// variants, their declared bandwidth/resolution, segment lists with optional
/// byte ranges, and the encryption flag.
library;

/// One `#EXT-X-STREAM-INF` entry.
class HlsVariant {
  final Uri uri;
  final int? bandwidth;
  final int? averageBandwidth;
  final String? resolution;
  final String? codecs;
  final String? audioGroup;
  final String? subtitleGroup;
  final String? name;

  const HlsVariant({
    required this.uri,
    this.bandwidth,
    this.averageBandwidth,
    this.resolution,
    this.codecs,
    this.audioGroup,
    this.subtitleGroup,
    this.name,
  });

  /// Height parsed out of `1920x1080`, used for a `1080p` label.
  int? get height {
    final r = resolution;
    if (r == null) return null;
    final parts = r.toLowerCase().split('x');
    if (parts.length != 2) return null;
    return int.tryParse(parts[1].trim());
  }

  String get qualityLabel => height != null ? '${height}p' : (name ?? 'AUTO');

  @override
  String toString() => '$qualityLabel ${resolution ?? ''} ${bandwidth ?? ''}';
}

/// An `#EXT-X-MEDIA` rendition (audio or subtitle).
class HlsRendition {
  final String type;
  final String? groupId;
  final String? name;
  final String? language;
  final Uri? uri;
  final bool isDefault;

  const HlsRendition({
    required this.type,
    this.groupId,
    this.name,
    this.language,
    this.uri,
    this.isDefault = false,
  });
}

/// A resolved HLS master playlist.
class HlsMaster {
  final List<HlsVariant> variants;
  final List<HlsRendition> renditions;

  const HlsMaster({this.variants = const [], this.renditions = const []});

  bool get isEmpty => variants.isEmpty;

  List<HlsRendition> get audio =>
      renditions.where((r) => r.type == 'AUDIO').toList();

  List<HlsRendition> get subtitles =>
      renditions.where((r) => r.type == 'SUBTITLES').toList();
}

/// One media segment (or init section) of a media playlist.
class HlsSegment {
  final Uri uri;
  final double duration;
  final int? byterangeLength;
  final int? byterangeOffset;

  const HlsSegment({
    required this.uri,
    required this.duration,
    this.byterangeLength,
    this.byterangeOffset,
  });
}

/// A resolved HLS media playlist.
class HlsMedia {
  final List<HlsSegment> segments;
  final Uri? initSegment;
  final int? initByterangeLength;
  final double duration;
  final bool encrypted;

  const HlsMedia({
    required this.segments,
    required this.duration,
    this.initSegment,
    this.initByterangeLength,
    this.encrypted = false,
  });
}

bool looksLikePlaylist(String body) => body.trimLeft().startsWith('#EXTM3U');

bool isMasterPlaylist(String body) =>
    body.contains('#EXT-X-STREAM-INF') ||
    body.contains('#EXT-X-I-FRAME-STREAM-INF');

/// Splits `KEY=VALUE,KEY="VA,LUE"` into a map, respecting quoted commas.
Map<String, String> parseAttributeList(String input) {
  final out = <String, String>{};
  final buffer = StringBuffer();
  var inQuotes = false;
  final parts = <String>[];

  for (var i = 0; i < input.length; i++) {
    final ch = input[i];
    if (ch == '"') {
      inQuotes = !inQuotes;
      buffer.write(ch);
    } else if (ch == ',' && !inQuotes) {
      parts.add(buffer.toString());
      buffer.clear();
    } else {
      buffer.write(ch);
    }
  }
  if (buffer.isNotEmpty) parts.add(buffer.toString());

  for (final part in parts) {
    final eq = part.indexOf('=');
    if (eq <= 0) continue;
    final key = part.substring(0, eq).trim().toUpperCase();
    var value = part.substring(eq + 1).trim();
    if (value.length >= 2 && value.startsWith('"') && value.endsWith('"')) {
      value = value.substring(1, value.length - 1);
    }
    out[key] = value;
  }
  return out;
}

HlsMaster parseMasterPlaylist(String body, Uri base) {
  final lines = body.split(RegExp(r'\r?\n'));
  final variants = <HlsVariant>[];
  final renditions = <HlsRendition>[];
  Map<String, String>? pending;

  for (final rawLine in lines) {
    final line = rawLine.trim();
    if (line.isEmpty) continue;

    if (line.startsWith('#EXT-X-STREAM-INF:')) {
      pending = parseAttributeList(line.substring('#EXT-X-STREAM-INF:'.length));
      continue;
    }
    if (line.startsWith('#EXT-X-MEDIA:')) {
      final a = parseAttributeList(line.substring('#EXT-X-MEDIA:'.length));
      renditions.add(HlsRendition(
        type: (a['TYPE'] ?? '').toUpperCase(),
        groupId: a['GROUP-ID'],
        name: a['NAME'],
        language: a['LANGUAGE'],
        uri: a['URI'] == null ? null : base.resolve(a['URI']!),
        isDefault: (a['DEFAULT'] ?? '').toUpperCase() == 'YES',
      ));
      continue;
    }
    if (line.startsWith('#')) continue;

    if (pending != null) {
      variants.add(HlsVariant(
        uri: base.resolve(line),
        bandwidth: int.tryParse(pending['BANDWIDTH'] ?? ''),
        averageBandwidth: int.tryParse(pending['AVERAGE-BANDWIDTH'] ?? ''),
        resolution: pending['RESOLUTION'],
        codecs: pending['CODECS'],
        audioGroup: pending['AUDIO'],
        subtitleGroup: pending['SUBTITLES'],
        name: pending['NAME'],
      ));
      pending = null;
    }
  }

  return HlsMaster(variants: variants, renditions: renditions);
}

HlsMedia parseMediaPlaylist(String body, Uri base) {
  final lines = body.split(RegExp(r'\r?\n'));
  final segments = <HlsSegment>[];
  double total = 0;
  double pendingDuration = 0;
  int? pendingRangeLength;
  int? pendingRangeOffset;
  Uri? initSegment;
  int? initLength;
  var encrypted = false;

  for (final rawLine in lines) {
    final line = rawLine.trim();
    if (line.isEmpty) continue;

    if (line.startsWith('#EXTINF:')) {
      final value = line.substring('#EXTINF:'.length).split(',').first.trim();
      pendingDuration = double.tryParse(value) ?? 0;
      continue;
    }
    if (line.startsWith('#EXT-X-BYTERANGE:')) {
      final spec = line.substring('#EXT-X-BYTERANGE:'.length).trim();
      final at = spec.split('@');
      pendingRangeLength = int.tryParse(at[0]);
      if (at.length > 1) pendingRangeOffset = int.tryParse(at[1]);
      continue;
    }
    if (line.startsWith('#EXT-X-KEY:')) {
      final a = parseAttributeList(line.substring('#EXT-X-KEY:'.length));
      final method = (a['METHOD'] ?? '').toUpperCase();
      if (method.isNotEmpty && method != 'NONE') encrypted = true;
      continue;
    }
    if (line.startsWith('#EXT-X-MAP:')) {
      final a = parseAttributeList(line.substring('#EXT-X-MAP:'.length));
      final uri = a['URI'];
      if (uri != null) initSegment = base.resolve(uri);
      final br = a['BYTERANGE'];
      if (br != null) initLength = int.tryParse(br.split('@').first);
      continue;
    }
    if (line.startsWith('#')) continue;

    final uri = base.resolve(line);
    segments.add(HlsSegment(
      uri: uri,
      duration: pendingDuration,
      byterangeLength: pendingRangeLength,
      byterangeOffset: pendingRangeOffset,
    ));
    total += pendingDuration;
    pendingDuration = 0;
    pendingRangeLength = null;
    pendingRangeOffset = null;
  }

  return HlsMedia(
    segments: segments,
    duration: total,
    initSegment: initSegment,
    initByterangeLength: initLength,
    encrypted: encrypted,
  );
}

/// Very small DASH reader — enough for bandwidth + duration.
class DashInfo {
  final int? bandwidth;
  final double? durationSeconds;
  final bool encrypted;

  const DashInfo(
      {this.bandwidth, this.durationSeconds, this.encrypted = false});
}

DashInfo parseDashManifest(String xml) {
  int? bandwidth;
  final bwMatches = RegExp(r'bandwidth="(\d+)"', caseSensitive: false)
      .allMatches(xml)
      .map((m) => int.tryParse(m.group(1)!))
      .whereType<int>();
  if (bwMatches.isNotEmpty) {
    bandwidth = bwMatches.reduce((a, b) => a > b ? a : b);
  }

  double? duration;
  final dur = RegExp(
    r'mediaPresentationDuration="PT(?:(\d+)H)?(?:(\d+)M)?(?:([\d.]+)S)?"',
  ).firstMatch(xml);
  if (dur != null) {
    final h = int.tryParse(dur.group(1) ?? '') ?? 0;
    final m = int.tryParse(dur.group(2) ?? '') ?? 0;
    final s = double.tryParse(dur.group(3) ?? '') ?? 0;
    duration = h * 3600 + m * 60 + s;
  }

  return DashInfo(
    bandwidth: bandwidth,
    durationSeconds: duration,
    encrypted: xml.contains('ContentProtection'),
  );
}

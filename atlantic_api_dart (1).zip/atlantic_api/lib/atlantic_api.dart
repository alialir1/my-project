/// Reverse-engineered Atlantic streaming API.
///
/// ```dart
/// final api = AtlanticAggregator(
///   probe: SizeProbe(http: AtlanticHttp(), mode: SizeProbeMode.sampled),
/// );
/// final result = await api.resolve(MediaRef.movie(1368337));
/// for (final s in result.servers) {
///   print('${s.provider} ${s.quality} ${s.size?.human} ${s.url}');
/// }
/// ```
library;

export 'src/aggregator.dart';
export 'src/manifest.dart'
    show
        HlsMaster,
        HlsMedia,
        HlsSegment,
        HlsVariant,
        isMasterPlaylist,
        looksLikePlaylist,
        parseMasterPlaylist,
        parseMediaPlaylist,
        parseAttributeList,
        parseDashManifest;
export 'src/models.dart';
export 'src/net.dart';
export 'src/probe.dart';
export 'src/providers.dart';
